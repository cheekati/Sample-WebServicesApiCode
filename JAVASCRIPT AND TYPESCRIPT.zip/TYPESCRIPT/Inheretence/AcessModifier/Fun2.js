"use strict";
exports.__esModule = true;
exports.fn2 = void 0;
var Fun1_1 = require("./Fun1");
function fn2() {
    console.log("fun2nn");
}
exports.fn2 = fn2;
(0, Fun1_1.fun1)();
console.log(Fun1_1.city);
(0, Fun1_1.name)("gag");
