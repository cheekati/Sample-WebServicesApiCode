export function fun1(){
    console.log ("function1 is calling")
}
export var city:string="jaipur"
export function name(n){
    console.log(n)
}
fun1()