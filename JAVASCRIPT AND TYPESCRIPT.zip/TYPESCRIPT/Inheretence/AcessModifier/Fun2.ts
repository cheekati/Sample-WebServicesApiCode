import {fun1,name,city} from "./Fun1"
 export function fn2(){
    console.log("fun2nn")
}
fun1()
console.log(city) 
name("gag")
