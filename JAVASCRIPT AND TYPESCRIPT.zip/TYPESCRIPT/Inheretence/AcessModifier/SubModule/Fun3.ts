import {fn2} from "../Fun2"

fn2()