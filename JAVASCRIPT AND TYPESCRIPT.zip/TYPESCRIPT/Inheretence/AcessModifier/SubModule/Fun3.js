"use strict";
exports.__esModule = true;
var Fun2_1 = require("../Fun2");
(0, Fun2_1.fn2)();
