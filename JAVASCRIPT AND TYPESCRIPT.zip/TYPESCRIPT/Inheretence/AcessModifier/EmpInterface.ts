interface empuu{
    name:string
    phone:number
    email: string

}
var EmpInterface:empuu ={
    name:"hhah",
    phone:9999,
    email:"ganesh@gmail.com"

}
console.log(EmpInterface.email)
