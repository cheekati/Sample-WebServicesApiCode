var EmpInterface = {
    name: "hhah",
    phone: 9999,
    email: "ganesh@gmail.com"
};
console.log(EmpInterface.email);
