class A1
{
    private pen:number=999
    public paper:number=9
    PP(){
        console.log(this.paper)

    }
}
class b2 extends  A1 {
}
var k= new A1
k.PP()