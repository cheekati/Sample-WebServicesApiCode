import {A9} from "./Class1"

var a69=new A9()

a69.print()