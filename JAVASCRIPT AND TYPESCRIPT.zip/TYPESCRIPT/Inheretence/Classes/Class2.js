"use strict";
exports.__esModule = true;
var Class1_1 = require("./Class1");
var a69 = new Class1_1.A9();
a69.print();
