"use strict";
exports.__esModule = true;
exports.A9 = void 0;
var A9 = /** @class */ (function () {
    function A9() {
        this.name = "nit";
        this.city = "HYD";
    }
    A9.prototype.print = function () {
        console.log(this.name, this.city);
    };
    return A9;
}());
exports.A9 = A9;
