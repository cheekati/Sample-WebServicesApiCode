export class A9{
    name:string="nit"
    city:string="HYD"

    print (){
        console.log(this.name,this.city) 
    }
}