var student = [78, 88, 98,];
var names = ["uhuh", "jhguy"];
var city = [];
city[0] = "hello";
city[1] = 77;
console.log(city);
