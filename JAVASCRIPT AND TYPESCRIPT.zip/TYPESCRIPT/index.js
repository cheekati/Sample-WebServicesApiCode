function fn(){
var i=0;
if (i==8) {
    var y="gane";
    let id =1999;
    console.log(i);
    
    
}else{
    i=100;
console.log(y);
console.log(i);
console.log(y);
}console.log(y);}
fn();