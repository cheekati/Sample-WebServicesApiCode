function fnshadowing(){
    var x= 10;
    var x="NIT";
    console.log(x);
    
}
fnshadowing()