var city;
city = 90;
city = "jiih";
console.log(city);
