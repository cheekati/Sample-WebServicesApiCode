function fnHosting(){
    x=99;
    console.log(x)
    var x;
}
fnHosting()