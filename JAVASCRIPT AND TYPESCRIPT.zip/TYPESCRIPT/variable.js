var city = "hyd";
city = "uk";
console.log(city);
var phone = 99999989;
console.log(phone);
