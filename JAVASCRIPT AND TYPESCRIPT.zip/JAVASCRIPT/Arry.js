var companyDetails= [100,"NIT",{city:"hyd",state:"TS"}]

console.log(companyDetails[1]);